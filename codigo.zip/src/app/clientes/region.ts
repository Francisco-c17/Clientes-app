export class Region {
  id: number;
  region: string;
}

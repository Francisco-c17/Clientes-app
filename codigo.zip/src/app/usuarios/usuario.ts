export class Usuario {
  id: number;
  username: string;
  nombre: string;
  password: string;
  apellido: string;
  email: string;
  roles: string[] = [];
}
